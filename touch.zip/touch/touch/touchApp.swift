//
//  touchApp.swift
//  touch
//
//  Created by User13 on 2020/12/9.
//

import SwiftUI

@main
struct touchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
